import jwt from 'jsonwebtoken';
import https from 'https';
import http from 'http';

/**
 * Bot that maintains lobby in a Jitsi room and auto-admits teachers
 * 
 * NOTE: This is a simplified version that uses JWT and Jitsi's HTTP API
 * For full bot functionality with lib-jitsi-meet, additional setup is required
 */
class RoomBot {
  constructor(roomName) {
    this.roomName = roomName;
    this.domain = process.env.JITSI_DOMAIN || 'meet.jit.si';
    this.isActive = false;
    this.checkInterval = null;
  }

  /**
   * Generate JWT for the bot (with moderator privileges)
   */
  generateBotToken() {
    if (!process.env.JWT_SECRET) {
      console.warn('⚠️  No JWT_SECRET configured, bot will not have moderator privileges');
      return null;
    }

    const payload = {
      context: {
        user: {
          id: `bot-${this.roomName}`,
          name: process.env.BOT_DISPLAY_NAME || 'Lobby Bot',
          moderator: true,
          hidden: true,
        },
      },
      room: this.roomName,
      sub: this.domain,
      iss: process.env.JWT_APP_ID || process.env.JWT_ISSUER,
      aud: 'jitsi',
      exp: Math.floor(Date.now() / 1000) + (60 * 60 * 24 * 7), // 7 days
    };

    return jwt.sign(payload, process.env.JWT_SECRET);
  }

  /**
   * Start the bot
   * 
   * NOTE: This is a placeholder implementation
   * Full bot functionality requires either:
   * 1. XMPP connection with prosody
   * 2. Jitsi Meet iframe API integration
   * 3. Custom WebSocket/REST API integration
   */
  async start() {
    console.log(`🤖 [${this.roomName}] Bot service initialized`);
    console.log(`📍 [${this.roomName}] Room: https://${this.domain}/${this.roomName}`);
    
    const token = this.generateBotToken();
    if (token) {
      console.log(`🔐 [${this.roomName}] JWT token generated for bot`);
    }
    
    this.isActive = true;
    
    // Set up periodic check (placeholder)
    this.checkInterval = setInterval(() => {
      if (this.isActive) {
        console.log(`✅ [${this.roomName}] Bot monitoring room`);
      }
    }, 60000); // Check every minute
    
    console.log(`✅ [${this.roomName}] Bot started successfully`);
    console.log(`ℹ️  [${this.roomName}] Teachers with JWT will be auto-admitted via Jitsi config`);
    
    return Promise.resolve();
  }

  /**
   * Stop the bot
   */
  stop() {
    console.log(`🛑 [${this.roomName}] Stopping bot...`);
    
    this.isActive = false;
    
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
    
    console.log(`✅ [${this.roomName}] Bot stopped`);
  }

  /**
   * Check if bot is connected
   */
  isConnected() {
    return this.isActive;
  }

  /**
   * Get participant count (placeholder)
   */
  getParticipantCount() {
    return 0;
  }
}

export default RoomBot;

/**
 * Bot that maintains lobby in a Jitsi room and auto-admits teachers
 */
class RoomBot {
  constructor(roomName) {
    this.roomName = roomName;
    this.domain = process.env.JITSI_DOMAIN || 'meet.jit.si';
    this.connection = null;
    this.room = null;
    this.isActive = false;
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 5;
    this.reconnectDelay = 5000;
  }

  /**
   * Generate JWT for the bot (with moderator privileges)
   */
  generateBotToken() {
    if (!process.env.JWT_SECRET) {
      console.warn('⚠️  No JWT_SECRET configured, bot will join without JWT');
      return null;
    }

    const payload = {
      context: {
        user: {
          id: `bot-${this.roomName}`,
          name: process.env.BOT_DISPLAY_NAME || 'Lobby Bot',
          moderator: true, // Bot is moderator to enable/manage lobby
          hidden: true, // Hide from participant list if supported
        },
      },
      room: this.roomName,
      sub: this.domain,
      iss: process.env.JWT_APP_ID || process.env.JWT_ISSUER,
      aud: 'jitsi',
      exp: Math.floor(Date.now() / 1000) + (60 * 60 * 24), // 24 hours
    };

    return jwt.sign(payload, process.env.JWT_SECRET);
  }

  /**
   * Start the bot
   */
  async start() {
    return new Promise((resolve, reject) => {
      console.log(`🤖 [${this.roomName}] Connecting bot...`);

      const options = {
        hosts: {
          domain: this.domain,
          muc: `conference.${this.domain}`,
        },
        serviceUrl: `https://${this.domain}/http-bind`,
      };

      // Add JWT if configured
      const token = this.generateBotToken();
      if (token) {
        options.jwt = token;
        console.log(`🔐 [${this.roomName}] Using JWT authentication`);
      }

      this.connection = new JitsiMeetJS.JitsiConnection(null, token, options);

      // Connection successful
      this.connection.addEventListener(
        JitsiMeetJS.events.connection.CONNECTION_ESTABLISHED,
        () => {
          console.log(`✅ [${this.roomName}] Bot connected`);
          this.onConnectionEstablished();
          resolve();
        }
      );

      // Connection failed
      this.connection.addEventListener(
        JitsiMeetJS.events.connection.CONNECTION_FAILED,
        (error) => {
          console.error(`❌ [${this.roomName}] Connection failed:`, error);
          this.handleConnectionFailure();
          reject(error);
        }
      );

      // Connection disconnected
      this.connection.addEventListener(
        JitsiMeetJS.events.connection.CONNECTION_DISCONNECTED,
        () => {
          console.log(`⚠️  [${this.roomName}] Bot disconnected`);
          this.handleDisconnect();
        }
      );

      // Connect
      this.connection.connect();
    });
  }

  /**
   * Handle successful connection
   */
  onConnectionEstablished() {
    const conferenceOptions = {
      openBridgeChannel: true,
      startWithAudioMuted: true,
      startWithVideoMuted: true,
    };

    this.room = this.connection.initJitsiConference(
      this.roomName,
      conferenceOptions
    );

    // Conference joined
    this.room.on(JitsiMeetJS.events.conference.CONFERENCE_JOINED, () => {
      console.log(`🎉 [${this.roomName}] Bot joined conference`);
      this.isActive = true;
      this.reconnectAttempts = 0;

      // Enable lobby immediately
      this.enableLobby();
      
      // Mute bot
      this.room.getLocalTracks().forEach(track => {
        if (track.getType() === 'audio') {
          track.mute();
        }
      });
    });

    // User joined lobby
    this.room.on(JitsiMeetJS.events.conference.LOBBY_USER_JOINED, (id, displayName) => {
      console.log(`🚪 [${this.roomName}] User knocking: ${displayName} (${id})`);
      this.handleLobbyUser(id);
    });

    // User left lobby
    this.room.on(JitsiMeetJS.events.conference.LOBBY_USER_LEFT, (id) => {
      console.log(`👋 [${this.roomName}] User left lobby: ${id}`);
    });

    // Participant joined conference
    this.room.on(JitsiMeetJS.events.conference.USER_JOINED, (id, participant) => {
      console.log(`👤 [${this.roomName}] User joined: ${participant._displayName}`);
    });

    // Participant left conference
    this.room.on(JitsiMeetJS.events.conference.USER_LEFT, (id) => {
      console.log(`👤 [${this.roomName}] User left: ${id}`);
    });

    // Lobby enabled/disabled
    this.room.on(JitsiMeetJS.events.conference.LOBBY_ENABLED, () => {
      console.log(`🔒 [${this.roomName}] Lobby enabled`);
    });

    this.room.on(JitsiMeetJS.events.conference.LOBBY_DISABLED, () => {
      console.log(`🔓 [${this.roomName}] Lobby disabled - re-enabling...`);
      // Auto re-enable lobby if someone disables it
      setTimeout(() => this.enableLobby(), 1000);
    });

    // Join the conference
    this.room.join();
  }

  /**
   * Enable lobby
   */
  enableLobby() {
    if (!this.room) return;

    try {
      this.room.enableLobby();
      console.log(`✅ [${this.roomName}] Lobby enabled successfully`);
    } catch (error) {
      console.error(`❌ [${this.roomName}] Failed to enable lobby:`, error);
    }
  }

  /**
   * Handle user in lobby - auto-admit teachers
   */
  async handleLobbyUser(participantId) {
    try {
      // Get participant info from lobby
      const participant = this.room.getLobbyParticipant(participantId);
      
      if (!participant) {
        console.warn(`⚠️  [${this.roomName}] Participant ${participantId} not found in lobby`);
        return;
      }

      console.log(`🔍 [${this.roomName}] Checking participant:`, {
        id: participantId,
        name: participant.name,
        role: participant.role,
        isModerator: participant.role === 'moderator',
      });

      // Auto-admit if they have moderator role (from JWT)
      if (participant.role === 'moderator') {
        console.log(`✅ [${this.roomName}] Auto-admitting teacher: ${participant.name}`);
        this.room.lobbyApproveAccess(participantId);
      } else {
        console.log(`⏸️  [${this.roomName}] Student waiting in lobby: ${participant.name}`);
        // Students stay in lobby until teacher manually admits them
      }
    } catch (error) {
      console.error(`❌ [${this.roomName}] Error handling lobby user:`, error);
    }
  }

  /**
   * Handle connection failure
   */
  handleConnectionFailure() {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      const delay = this.reconnectDelay * this.reconnectAttempts;
      
      console.log(
        `🔄 [${this.roomName}] Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts})...`
      );
      
      setTimeout(() => {
        this.start().catch(err => {
          console.error(`❌ [${this.roomName}] Reconnection failed:`, err);
        });
      }, delay);
    } else {
      console.error(
        `❌ [${this.roomName}] Max reconnection attempts reached, giving up`
      );
      this.isActive = false;
    }
  }

  /**
   * Handle disconnect
   */
  handleDisconnect() {
    this.isActive = false;
    
    // Attempt to reconnect
    setTimeout(() => {
      if (!this.isActive) {
        console.log(`🔄 [${this.roomName}] Attempting to reconnect...`);
        this.start().catch(err => {
          console.error(`❌ [${this.roomName}] Reconnection failed:`, err);
        });
      }
    }, this.reconnectDelay);
  }

  /**
   * Stop the bot
   */
  stop() {
    console.log(`🛑 [${this.roomName}] Stopping bot...`);
    
    this.isActive = false;
    
    if (this.room) {
      this.room.leave();
      this.room = null;
    }
    
    if (this.connection) {
      this.connection.disconnect();
      this.connection = null;
    }
    
    console.log(`✅ [${this.roomName}] Bot stopped`);
  }

  /**
   * Check if bot is connected
   */
  isConnected() {
    return this.isActive && this.connection && this.room;
  }

  /**
   * Get participant count
   */
  getParticipantCount() {
    if (!this.room) return 0;
    return this.room.getParticipants().length;
  }
}

export default RoomBot;
